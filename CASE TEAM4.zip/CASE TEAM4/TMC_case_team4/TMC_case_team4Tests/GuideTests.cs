﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TMC_case_team4.Pages.MainPages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TMC_case_team4.Pages.MainPages.Tests
{
    [TestClass()]
    public class GuideTests
    {
        Guide Gde = new Guide();
        [TestMethod()]
        public void MaxLengthCategortTest()
        {
            Assert.AreEqual(Gde.MaxLengthTbx("category"), 99);
        }
        [TestMethod()]
        public void MaxLengthCompanyTest()
        {
            Assert.AreEqual(Gde.MaxLengthTbx("company"), 149);
        }
        [TestMethod()]
        public void MaxLengthStatusTest()
        {
            Assert.AreEqual(Gde.MaxLengthTbx("status"), 99);
        }
        [TestMethod()]
        public void MaxLengthDivisionTest()
        {
            Assert.AreEqual(Gde.MaxLengthTbx("division"), 99);
        }
        [TestMethod()]
        public void MaxLengthRecTest()
        {
            Assert.AreEqual(Gde.MaxLengthTbx("Rec"), 0);
        }
    }
}