﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Excel;
using System.IO;
using System.Windows.Forms;

namespace TMC_case_team4.Data
{
    internal class ExcelHelper: IDisposable
    {
        SaveFileDialog sfd = new SaveFileDialog();

        private string _filePath;

        private Workbook _workbook;
        private Excel.Application _excel;

        public ExcelHelper()
        {
            _excel = new Excel.Application();
        }

        internal bool Open(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    _workbook = _excel.Workbooks.Open(filePath);
                }
                else
                {
                    _workbook = _excel.Workbooks.Add();
                    _filePath = filePath;
                }

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return false;
        }

        internal void Save()
        {
            sfd.Filter = "(.xlsx)|*.xlsx";
            if (!string.IsNullOrEmpty(_filePath))
            {
                if (sfd.ShowDialog() == DialogResult.Cancel)
                    return;

                _workbook.SaveAs(sfd.FileName);
                _filePath = null;
            }
            else
            {
                _workbook.Save();
            }
        }

        internal bool Open(object filePath)
        {
            throw new NotImplementedException();
        }

        internal bool Set(string colume, int row, object data)
        {
            try
            {
                ((Excel.Worksheet)_excel.ActiveSheet).Cells[row, colume] = data;
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public void Dispose()
        {
            try
            {
                _workbook.Close();
                _excel.Quit();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
