﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace TMC_case_team4.Data
{
    class FrameApp
    {
        public static Frame frmObj;
    }
}
