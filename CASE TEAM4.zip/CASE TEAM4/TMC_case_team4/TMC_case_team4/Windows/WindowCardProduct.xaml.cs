﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TMC_case_team4.Data;
using Path = System.IO.Path;
using Excel = Microsoft.Office.Interop.Excel;

namespace TMC_case_team4.Windows
{
    /// <summary>
    /// Логика взаимодействия для WindowCardProduct.xaml
    /// </summary>
    public partial class WindowCardProduct : Window
    {
        public WindowCardProduct()
        {
            InitializeComponent();
            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
            List<string> list = new List<string> {"Фамилия ответственного", "Предприятие", "Статус", "Номер Акта", "Инвентарный номер"};
            cb_sort.ItemsSource = list;

            //
            dtpFirst.DisplayDateStart = OdbConnectHelper.entObj.Act.Min(x => x.commissioningDate);
            dtpFirst.DisplayDateEnd = OdbConnectHelper.entObj.Act.Max(x => x.commissioningDate);

            //dtpSecond.DisplayDateStart = OdbConnectHelper.entObj.Act.Min(x => x.commissioningDate);
            dtpSecond.DisplayDateEnd = OdbConnectHelper.entObj.Act.Max(x => x.commissioningDate);
            //

            //
            //GridList.
            //

        }

        private void GridList_Loaded(object sender, RoutedEventArgs e)
        {           
            Cb.ItemsSource = OdbConnectHelper.entObj.Status.ToList();
            Cb.DisplayMemberPath = "title";
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            OdbConnectHelper.entObj.SaveChanges();
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            
            //
            dtpFirst.SelectedDate = null;
            dtpSecond.SelectedDate = null;
            dtpSecond.Visibility = Visibility.Hidden;

            //
            cb_item.SelectedItem = null;           
            cb_sort.SelectedItem = null;

            cb_item.IsEnabled = false;
            tbsearch.IsEnabled = false;

            tbsearch.Text = "";
            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();            
        }

        

        private void btnadd_click(object sender, RoutedEventArgs e)
        {
            WindowCardProductAdd wcpAdd = new WindowCardProductAdd();
            wcpAdd.ShowDialog();
        }

        private void cb_sort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            cb_item.IsEnabled = true;
            tbsearch.Text = "";
            tbsearch.Visibility = Visibility.Collapsed;
            switch (cb_sort.SelectedItem)
            {
                //вот тут чото посмотреть с отображением может быть ошибки
                case "Фамилия ответственного":
                    cb_item.Visibility = Visibility.Visible;
                    tbsearch.Visibility = Visibility.Collapsed;
                    cb_item.DisplayMemberPath = "surname";
                    cb_item.SelectedValuePath = "surname";
                    cb_item.ItemsSource = from x in OdbConnectHelper.entObj.Responsible_persons.Local group x by x.surname into g select new { surname = g.Key };
                    break;
                case "Предприятие":
                    cb_item.Visibility = Visibility.Visible;
                    tbsearch.Visibility = Visibility.Collapsed;
                    cb_item.DisplayMemberPath = "title";
                    cb_item.SelectedValuePath = "ID_company";
                    cb_item.ItemsSource = OdbConnectHelper.entObj.Company.ToList();
                    break;
                case "Статус":
                    cb_item.Visibility = Visibility.Visible;
                    tbsearch.Visibility = Visibility.Collapsed;
                    cb_item.DisplayMemberPath = "title";
                    cb_item.SelectedValuePath = "ID_status";
                    cb_item.ItemsSource = OdbConnectHelper.entObj.Status.ToList();
                    break;
                case "Номер Акта":
                    cb_item.Visibility = Visibility.Collapsed;
                    tbsearch.Visibility = Visibility.Visible;
                    tbsearch.IsEnabled = true;
                    break;
                case "Инвентарный номер":
                    cb_item.Visibility = Visibility.Collapsed;
                    tbsearch.Visibility = Visibility.Visible;
                    tbsearch.IsEnabled = true;
                    break;
                case "":
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
                    break;
                default:
                    break;
            }
        }

        private void cb_item_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //
            dtpFirst.SelectedDate = null;
            dtpSecond.SelectedDate = null;
            //

            if (cb_item.SelectedValue == null)
            {
                return;
            }
            string select = cb_item.SelectedValue.ToString();
            switch (cb_sort.SelectedItem.ToString())
            {
                case "Фамилия ответственного":
                    var testobj = OdbConnectHelper.entObj.Responsible_persons.FirstOrDefault(x => x.surname == cb_item.SelectedValue);
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_responsible_persons == testobj.ID_responsible_persons).ToList();
                    break;
                case "Предприятие":
                    int abv = Convert.ToInt32(cb_item.SelectedValue);
                    var testobj1 = OdbConnectHelper.entObj.Company.FirstOrDefault(x => x.ID_company == abv);
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.Responsible_persons.ID_company == testobj1.ID_company).ToList();
                    break;
                case "Статус":
                    int abv1 = Convert.ToInt32(cb_item.SelectedValue);
                    var testobj2 = OdbConnectHelper.entObj.Status.FirstOrDefault(x => x.ID_status == abv1);
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_status== testobj2.ID_status).ToList();
                    break;
                case "":
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
                    break;
                default:
                    break;
            }
        }
        //
        //Дата может зависеть от фильтра, но фильтр от даты нет
        private void dtpFirst_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {   
            dtpSecond.Visibility = Visibility.Visible;
            if (dtpFirst.SelectedDate == null)
            {
                //GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
            }
            
            dtpSecond.DisplayDateStart = dtpFirst.SelectedDate; //+1 надо лучше

            if (cb_item.SelectedItem != null || tbsearch.Text != "")
            {
                switch (cb_sort.SelectedItem.ToString())
                {
                    case "Фамилия ответственного":
                        var testobj = OdbConnectHelper.entObj.Responsible_persons.FirstOrDefault(x => x.surname == cb_item.SelectedValue);
                        GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_responsible_persons == testobj.ID_responsible_persons
                                                                                      && x.Act.commissioningDate >= dtpFirst.SelectedDate).ToList();
                        break;
                    case "Предприятие":
                        int abv = Convert.ToInt32(cb_item.SelectedValue);
                        var testobj1 = OdbConnectHelper.entObj.Company.FirstOrDefault(x => x.ID_company == abv);
                        GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.Responsible_persons.ID_company == testobj1.ID_company
                                                                                      && x.Act.commissioningDate >= dtpFirst.SelectedDate).ToList();
                        break;
                    case "Статус":
                        int abv1 = Convert.ToInt32(cb_item.SelectedValue);
                        var testobj2 = OdbConnectHelper.entObj.Status.FirstOrDefault(x => x.ID_status == abv1);
                        GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_status == testobj2.ID_status
                                                                                      && x.Act.commissioningDate >= dtpFirst.SelectedDate).ToList();
                        break;
                    case "Номер Акта":
                        GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.number_act.ToString().StartsWith(tbsearch.Text)
                                                                                           && x.Act.commissioningDate >= dtpFirst.SelectedDate).ToList();
                        break;
                    case "Инвентарный номер":
                        GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.inventory_number.ToString().StartsWith(tbsearch.Text.ToString())
                                                                                      && x.Act.commissioningDate >= dtpFirst.SelectedDate).ToList();
                        break;
                    default:
                        break;
                }
            }
            else
            {
                GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.Act.commissioningDate >= dtpFirst.SelectedDate).ToList();
            }
        }

        private void dtpSecond_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dtpSecond.SelectedDate == null)
            {
                //GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
            }
            if (dtpFirst.SelectedDate != null || tbsearch.Text != "")
            {
                if (cb_item.SelectedItem != null)
                {
                    switch (cb_sort.SelectedItem.ToString())
                    {
                        case "Фамилия ответственного":
                            var testobj = OdbConnectHelper.entObj.Responsible_persons.FirstOrDefault(x => x.surname == cb_item.SelectedValue);
                            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_responsible_persons == testobj.ID_responsible_persons
                                                                                               && x.Act.commissioningDate >= dtpFirst.SelectedDate
                                                                                               && x.Act.commissioningDate <= dtpSecond.SelectedDate).ToList();
                            break;
                        case "Предприятие":
                            int abv = Convert.ToInt32(cb_item.SelectedValue);
                            var testobj1 = OdbConnectHelper.entObj.Company.FirstOrDefault(x => x.ID_company == abv);
                            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.Responsible_persons.ID_company == testobj1.ID_company
                                                                                               && x.Act.commissioningDate >= dtpFirst.SelectedDate
                                                                                               && x.Act.commissioningDate <= dtpSecond.SelectedDate).ToList();
                            break;
                        case "Статус":
                            int abv1 = Convert.ToInt32(cb_item.SelectedValue);
                            var testobj2 = OdbConnectHelper.entObj.Status.FirstOrDefault(x => x.ID_status == abv1);
                            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_status == testobj2.ID_status
                                                                                               && x.Act.commissioningDate >= dtpFirst.SelectedDate
                                                                                                && x.Act.commissioningDate <= dtpSecond.SelectedDate).ToList();
                            break;
                        case "Номер Акта":
                            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.number_act.ToString().StartsWith(tbsearch.Text)
                                                                                               && x.Act.commissioningDate >= dtpFirst.SelectedDate
                                                                                               && x.Act.commissioningDate <= dtpSecond.SelectedDate).ToList();
                            break;
                        case "Инвентарный номер":
                            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.inventory_number.ToString().StartsWith(tbsearch.Text.ToString())
                                                                                               && x.Act.commissioningDate >= dtpFirst.SelectedDate
                                                                                               && x.Act.commissioningDate <= dtpSecond.SelectedDate).ToList();
                            break;
                        default:
                            break;
                    }
                }
                else
                {
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.Act.commissioningDate >= dtpFirst.SelectedDate && x.Act.commissioningDate <= dtpSecond.SelectedDate).ToList();
                }
            }

        }
        
        private void btnDecommission_click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (GridList.SelectedItems.Count > 0)
                {
                    MessageBoxResult result = MessageBox.Show($"Вы действительно хотите списать {GridList.SelectedItems.Count} запись(-и)?",
                                                          "Предупреждение",
                                                          MessageBoxButton.YesNo,
                                                          MessageBoxImage.Warning);
                    if (result == MessageBoxResult.Yes)
                    {
                        for (int i = 0; i < GridList.SelectedItems.Count;)
                        {
                            Product_map ProductMap = GridList.SelectedItems[i] as Product_map;
                            if (ProductMap != null)
                            {
                                Archiev archObj = new Archiev()
                                {
                                    number_act = ProductMap.number_act,
                                    ArchivationDate = System.DateTime.Now
                                };
                                OdbConnectHelper.entObj.Archiev.Add(archObj);
                                OdbConnectHelper.entObj.Product_map.Remove(ProductMap);
                                OdbConnectHelper.entObj.SaveChanges();
                                GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
                            }
                            else
                            {
                                return;
                            }
                        }
                        GridList.SelectedIndex = 0;
                        MessageBox.Show($"Продукт успешно списан",
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);;
                    }
                    if (result == MessageBoxResult.No)
                        return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(),
                                "Ошибка: Не выбрано поле",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);
            }
        }

        private void tbsearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            switch (cb_sort.Text)
            {
                case "Инвентарный номер":
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.inventory_number.ToString().StartsWith(tbsearch.Text)).ToList();
                    break;
                case "Номер Акта":
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.number_act.ToString().StartsWith(tbsearch.Text)).ToList();
                    break;
            }
        }

        private void LimitText_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0)) { e.Handled = true; }
        }

        private void btnExcelExport_Click(object sender, RoutedEventArgs e)
        {
            var checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.number_act == 1).ToList();

            if (cb_sort.SelectedItem == null && dtpFirst.SelectedDate == null)
                checkCbObj = OdbConnectHelper.entObj.Product_map.ToList();

            
            if(dtpSecond.SelectedDate != null)
            {
                if(cb_sort.SelectedValue != null || tbsearch.Text != "")
                {
                    switch (cb_sort.SelectedItem)
                    {
                        case "Фамилия ответственного":
                            var checkFIOObj = OdbConnectHelper.entObj.Responsible_persons.FirstOrDefault(x => x.surname == cb_item.SelectedValue.ToString());
                            checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_responsible_persons == checkFIOObj.ID_responsible_persons
                                                                                && x.Act.commissioningDate >= dtpFirst.SelectedDate
                                                                                && x.Act.commissioningDate <= dtpSecond.SelectedDate).ToList();
                            break;
                        case "Предприятие":
                            var checkCompanyObj = OdbConnectHelper.entObj.Company.FirstOrDefault(x => x.ID_company == (int)cb_item.SelectedValue);
                            checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.Responsible_persons.ID_responsible_persons == checkCompanyObj.ID_company
                                                                                && x.Act.commissioningDate >= dtpFirst.SelectedDate
                                                                                && x.Act.commissioningDate <= dtpSecond.SelectedDate).ToList();
                            break;
                        case "Статус":
                            var checkStatusObj = OdbConnectHelper.entObj.Status.FirstOrDefault(x => x.ID_status == (int)cb_item.SelectedValue);
                            checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_status == checkStatusObj.ID_status
                                                                                     && x.Act.commissioningDate >= dtpFirst.SelectedDate
                                                                                     && x.Act.commissioningDate <= dtpSecond.SelectedDate).ToList();
                            break;
                        case "Номер Акта":
                            checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.number_act.ToString().StartsWith(tbsearch.Text)
                                                                                     && x.Act.commissioningDate >= dtpFirst.SelectedDate
                                                                                     && x.Act.commissioningDate <= dtpSecond.SelectedDate).ToList();
                            break;
                        case "Инвентарный номер":
                            checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.inventory_number.ToString().StartsWith(tbsearch.Text.ToString())
                                                                                     && x.Act.commissioningDate >= dtpFirst.SelectedDate
                                                                                     && x.Act.commissioningDate <= dtpSecond.SelectedDate).ToList();
                            break;
                    }
                }
                else
                {
                    checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.Act.commissioningDate >= dtpFirst.SelectedDate
                                                                         && x.Act.commissioningDate <= dtpSecond.SelectedDate).ToList();
                }
            }
            else
            {
                if (cb_item.SelectedItem != null || tbsearch.Text != "")
                {
                    switch (cb_sort.SelectedItem)
                    {
                        case "Фамилия ответственного":
                            var checkFIOObj = OdbConnectHelper.entObj.Responsible_persons.FirstOrDefault(x => x.surname == cb_item.SelectedValue.ToString());
                            checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_responsible_persons == checkFIOObj.ID_responsible_persons
                                                                                && x.Act.commissioningDate >= dtpFirst.SelectedDate).ToList();
                            break;
                        case "Предприятие":
                            var checkCompanyObj = OdbConnectHelper.entObj.Company.FirstOrDefault(x => x.ID_company == (int)cb_item.SelectedValue);
                            checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.Responsible_persons.ID_responsible_persons == checkCompanyObj.ID_company
                                                                                && x.Act.commissioningDate >= dtpFirst.SelectedDate).ToList();
                            break;
                        case "Статус":
                            var checkStatusObj = OdbConnectHelper.entObj.Status.FirstOrDefault(x => x.ID_status == (int)cb_item.SelectedValue);
                            checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_status == checkStatusObj.ID_status
                                                                                     && x.Act.commissioningDate >= dtpFirst.SelectedDate).ToList();
                            break;
                        case "Номер Акта":
                            checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.number_act.ToString().StartsWith(tbsearch.Text)
                                                                                     && x.Act.commissioningDate >= dtpFirst.SelectedDate).ToList();
                            break;
                        case "Инвентарный номер":
                            checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.inventory_number.ToString().StartsWith(tbsearch.Text.ToString())
                                                                                     && x.Act.commissioningDate >= dtpFirst.SelectedDate).ToList();
                            break;
                    }
                }
                else
                {
                    if (dtpFirst.SelectedDate != null)
                    {
                        checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.Act.commissioningDate >= dtpFirst.SelectedDate).ToList();
                    }
                }
            }

            if (cb_item.SelectedValue != null)
            {
                switch (cb_sort.SelectedItem.ToString())
                {
                    case "Фамилия ответственного":
                        var checkFIOObj = OdbConnectHelper.entObj.Responsible_persons.FirstOrDefault(x => x.surname == cb_item.SelectedValue.ToString());
                        checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_responsible_persons == checkFIOObj.ID_responsible_persons).ToList();
                        break;
                    case "Предприятие":
                        var checkCompanyObj = OdbConnectHelper.entObj.Company.FirstOrDefault(x => x.ID_company == (int)cb_item.SelectedValue);
                        checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.Responsible_persons.ID_responsible_persons == checkCompanyObj.ID_company).ToList();
                        break;
                    case "Статус":
                        var checkStatusObj = OdbConnectHelper.entObj.Status.FirstOrDefault(x => x.ID_status == (int)cb_item.SelectedValue);
                        checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_status == checkStatusObj.ID_status).ToList();
                        break;
                }
            }

            if (tbsearch.Text != "")
            {
                switch (cb_sort.SelectedItem.ToString())
                {
                    case "Номер Акта":
                        checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.number_act.ToString().StartsWith(tbsearch.Text)).ToList();
                        break;
                    case "Инвентарный номер":
                        checkCbObj = OdbConnectHelper.entObj.Product_map.Where(x => x.inventory_number.ToString().StartsWith(tbsearch.Text.ToString())).ToList();
                        break;
                }
            }

            try
            {
                var application = new Excel.Application();
                application.SheetsInNewWorkbook = 1;

                Excel.Workbook workbook = application.Workbooks.Add(Type.Missing);

                Excel.Worksheet worksheet = application.Worksheets.Item[1];
                worksheet.Name = "Лист1";


                //worksheet.Range[worksheet.Cells[1][1], worksheet.Cells[1][5]].Value = "hrdhsxfhdfhdfdhfdfdffd";

                Excel.Range rangeBorders = worksheet.Range[worksheet.Cells[2][5], worksheet.Cells[12][checkCbObj.Count() + 6]];
                rangeBorders.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle =
                rangeBorders.Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle =
                rangeBorders.Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle =
                rangeBorders.Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle =
                rangeBorders.Borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle =
                rangeBorders.Borders[Excel.XlBordersIndex.xlInsideVertical].LineStyle = Excel.XlLineStyle.xlContinuous;
                rangeBorders.Font.Size = 14;

                Excel.Range headerRange = worksheet.Range[worksheet.Cells[2][5], worksheet.Cells[12][5]];
                headerRange.Merge();
                headerRange.Value = "Акт приёма передачи товара";
                headerRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                headerRange.Font.Size = 22;

                //Заголовки
                Excel.Range headers = worksheet.Range[worksheet.Cells[2][6], worksheet.Cells[12][6]];
                headers.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                headers.Font.Bold = true;
                headers.Font.Size = 16;

                worksheet.Cells[2][6] = "Ивентарный №";
                worksheet.Cells[3][6] = "Наименование";
                worksheet.Cells[4][6] = "Хар-ка";
                worksheet.Cells[5][6] = "Ответвенный";
                worksheet.Cells[6][6] = "Подразделение";
                worksheet.Cells[7][6] = "Предприятие";
                worksheet.Cells[8][6] = "Секрийный номер";
                worksheet.Cells[9][6] = "Категория";
                worksheet.Cells[10][6] = "Вход в экспл.";
                worksheet.Cells[11][6] = "№ Акта";
                worksheet.Cells[12][6] = "Статус";
                //

                int j = 7;
                foreach (var data in checkCbObj.ToList())
                {
                    worksheet.Cells[2][j] = data.inventory_number;
                    worksheet.Cells[3][j] = data.Act.Product.title;
                    worksheet.Cells[4][j] = data.specifications;
                    worksheet.Cells[5][j] = data.Responsible_persons.FIO;
                    worksheet.Cells[6][j] = data.Responsible_persons.Division.title;
                    worksheet.Cells[7][j] = data.Responsible_persons.Company.title;
                    worksheet.Cells[8][j] = data.serial_number;
                    worksheet.Cells[9][j] = data.Act.Product.Category.title;
                    worksheet.Cells[10][j] = data.Act.commissioningDate;
                    worksheet.Cells[11][j] = data.number_act;
                    worksheet.Cells[12][j] = data.Status.title;
                    j++;
                }

                worksheet.Columns.AutoFit();
                

                application.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
