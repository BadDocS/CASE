﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TMC_case_team4.Data;

namespace TMC_case_team4.Windows
{
    /// <summary>
    /// Логика взаимодействия для WindowCardProductAdd.xaml
    /// </summary>
    public partial class WindowCardProductAdd : Window
    {
        public WindowCardProductAdd()
        {
            InitializeComponent();

            cbProdName.SelectedValuePath = "ID_product";
            cbProdName.DisplayMemberPath = "title";
            cbProdName.ItemsSource = OdbConnectHelper.entObj.Product.ToList();

            cbRespPeop.SelectedValuePath = "ID_responsible_persons";
            cbRespPeop.DisplayMemberPath = "FIO";
            cbRespPeop.ItemsSource = OdbConnectHelper.entObj.Responsible_persons.ToList();

            cbStatus.SelectedValuePath = "ID_status";
            cbStatus.DisplayMemberPath = "title";
            cbStatus.ItemsSource = OdbConnectHelper.entObj.Status.ToList();
        }
        private void LimitText_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0)) { e.Handled = true; }
        }

        private void btnAddCardProd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (tbInvNum.Text != "")
                {
                    if (tbSerNum.Text != "")
                    {
                        if (cbNumAct.SelectedValue != null)
                        {
                            if (cbRespPeop.SelectedValue != null)
                            {
                                if (cbStatus.SelectedValue != null)
                                {
                                    if(OdbConnectHelper.entObj.Product_map.FirstOrDefault(x => x.serial_number == tbSerNum.Text) == null)
                                    {
                                        Product_map prmAddObj = new Product_map()
                                        {
                                            inventory_number = int.Parse(tbInvNum.Text),
                                            serial_number = tbSerNum.Text,
                                            number_act = (int)cbNumAct.SelectedValue,
                                            specifications = tbSpec.Text,
                                            ID_responsible_persons = (int)cbRespPeop.SelectedValue,
                                            ID_status = (int)cbStatus.SelectedValue
                                        };

                                        OdbConnectHelper.entObj.Product_map.Add(prmAddObj);
                                        OdbConnectHelper.entObj.SaveChanges();
                                        MessageBox.Show("Запись добавлена. Не забудте обновить таблицу");

                                        this.Close();
                                    }
                                    else
                                    {
                                        MessageBox.Show("Данный серийный номер уже используется");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Укажите статус товара!");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Выберите ответсвенное лицо !");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Выберите Номер акта! (Для разблокировки поля выберите продук)");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Введите Серийный номер!");
                    }
                }
                else
                {
                    MessageBox.Show("Введите инвентарный номер!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cbProdName_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            cbNumAct.IsEnabled = true;

            cbNumAct.SelectedValuePath = "number_act";
            cbNumAct.DisplayMemberPath = "number_act";
            cbNumAct.ItemsSource = OdbConnectHelper.entObj.Act.Where(x => x.ID_product == (int)cbProdName.SelectedValue).ToList();
        }
    }
}
