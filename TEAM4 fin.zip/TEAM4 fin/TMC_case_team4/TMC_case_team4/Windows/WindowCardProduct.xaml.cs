﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TMC_case_team4.Data;

namespace TMC_case_team4.Windows
{
    /// <summary>
    /// Логика взаимодействия для WindowCardProduct.xaml
    /// </summary>
    public partial class WindowCardProduct : Window
    {
        public WindowCardProduct()
        {
            InitializeComponent();
            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
            List<string> list = new List<string> {"Фамилия ответственного", "Предприятие", "Статус", "Инвентарный номер"};
            cb_sort.ItemsSource = list;

            //
            dtpFirst.DisplayDateStart = OdbConnectHelper.entObj.Act.Min(x => x.commissioningDate);
            dtpFirst.DisplayDateEnd = OdbConnectHelper.entObj.Act.Max(x => x.commissioningDate);

            //dtpSecond.DisplayDateStart = OdbConnectHelper.entObj.Act.Min(x => x.commissioningDate);
            dtpSecond.DisplayDateEnd = OdbConnectHelper.entObj.Act.Max(x => x.commissioningDate);
            //

            //
            //GridList.
            //

        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void GridList_Loaded(object sender, RoutedEventArgs e)
        {           
            Cb.ItemsSource = OdbConnectHelper.entObj.Status.ToList();
            Cb.DisplayMemberPath = "title";
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            OdbConnectHelper.entObj.SaveChanges();
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            //
            dtpSecond.SelectedDate = null;
            dtpSecond.Visibility = Visibility.Hidden; //не работает

            dtpFirst.SelectedDate = null;
            //
            cb_item.Text = "";
            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();            
        }

        

        private void btnadd_click(object sender, RoutedEventArgs e)
        {
            WindowCardProductAdd wcpAdd = new WindowCardProductAdd();
            wcpAdd.ShowDialog();
        }

        private void cb_sort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            cb_item.IsEnabled = true;
            switch (cb_sort.SelectedItem.ToString())
            {
                case "Фамилия ответственного":
                    cb_item.Visibility = Visibility.Visible;
                    tbsearch.Visibility = Visibility.Collapsed;
                    cb_item.DisplayMemberPath = "surname";
                    cb_item.SelectedValuePath = "surname";
                    cb_item.ItemsSource = from x in OdbConnectHelper.entObj.Responsible_persons.Local group x by x.surname into g select new { surname = g.Key };
                    break;
                case "Предприятие":
                    cb_item.Visibility = Visibility.Visible;
                    tbsearch.Visibility = Visibility.Collapsed;
                    cb_item.DisplayMemberPath = "title";
                    cb_item.SelectedValuePath = "ID_company";
                    cb_item.ItemsSource = OdbConnectHelper.entObj.Company.ToList();
                    break;
                case "Статус":
                    cb_item.Visibility = Visibility.Visible;
                    tbsearch.Visibility = Visibility.Collapsed;
                    cb_item.DisplayMemberPath = "title";
                    cb_item.SelectedValuePath = "ID_status";
                    cb_item.ItemsSource = OdbConnectHelper.entObj.Status.ToList();
                    break;
                case "Инвентарный номер":
                    cb_item.Visibility = Visibility.Collapsed;
                    tbsearch.Visibility = Visibility.Visible;
                    break;
                case "":
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
                    break;
                default:
                    break;
            }
        }

        private void cb_item_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //
            dtpFirst.SelectedDate = null;
            dtpSecond.SelectedDate = null;
            //

            if (cb_item.SelectedValue == null)
            {
                return;
            }
            string select = cb_item.SelectedValue.ToString();
            switch (cb_sort.SelectedItem.ToString())
            {
                case "Фамилия ответственного":
                    var testobj = OdbConnectHelper.entObj.Responsible_persons.FirstOrDefault(x => x.surname == cb_item.SelectedValue);
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_responsible_persons == testobj.ID_responsible_persons).ToList();
                    break;
                case "Предприятие":
                    int abv = Convert.ToInt32(cb_item.SelectedValue);
                    var testobj1 = OdbConnectHelper.entObj.Company.FirstOrDefault(x => x.ID_company == abv);
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.Responsible_persons.ID_company == testobj1.ID_company).ToList();
                    break;
                case "Статус":
                    int abv1 = Convert.ToInt32(cb_item.SelectedValue);
                    var testobj2 = OdbConnectHelper.entObj.Status.FirstOrDefault(x => x.ID_status == abv1);
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_status== testobj2.ID_status).ToList();
                    break;
                case "":
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
                    break;
                default:
                    break;
            }
        }
        //
        //Дата может зависеть от фильтра, но фильтр от даты нет
        private void dtpFirst_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            dtpSecond.Visibility = Visibility.Visible;
            if (dtpFirst.SelectedDate == null)
            {
                //GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
            }
            dtpSecond.DisplayDateStart = dtpFirst.SelectedDate; // лучше сделать + 1

            if (cb_item.SelectedItem != null)
            {
                switch (cb_sort.SelectedItem.ToString())
                {
                    case "Фамилия ответственного":
                        var testobj = OdbConnectHelper.entObj.Responsible_persons.FirstOrDefault(x => x.surname == cb_item.SelectedValue);
                        GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_responsible_persons == testobj.ID_responsible_persons
                                                                                      && x.Act.commissioningDate >= dtpFirst.SelectedDate).ToList();
                        break;
                    case "Предприятие":
                        int abv = Convert.ToInt32(cb_item.SelectedValue);
                        var testobj1 = OdbConnectHelper.entObj.Company.FirstOrDefault(x => x.ID_company == abv);
                        GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.Responsible_persons.ID_company == testobj1.ID_company
                                                                                      && x.Act.commissioningDate >= dtpFirst.SelectedDate).ToList();
                        break;
                    case "Статус":
                        int abv1 = Convert.ToInt32(cb_item.SelectedValue);
                        var testobj2 = OdbConnectHelper.entObj.Status.FirstOrDefault(x => x.ID_status == abv1);
                        GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_status == testobj2.ID_status
                                                                                      && x.Act.commissioningDate >= dtpFirst.SelectedDate).ToList();
                        break;
                    default:
                        break;
                }
            }
            else
            {
                GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.Act.commissioningDate >= dtpFirst.SelectedDate).ToList();
            }
        }

        private void dtpSecond_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dtpSecond.SelectedDate == null)
            {
                //GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
            }
            if (dtpFirst.SelectedDate != null)
            {
                if (cb_item.SelectedItem != null)
                {
                    switch (cb_sort.SelectedItem.ToString())
                    {
                        case "Фамилия ответственного":
                            var testobj = OdbConnectHelper.entObj.Responsible_persons.FirstOrDefault(x => x.surname == cb_item.SelectedValue);
                            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_responsible_persons == testobj.ID_responsible_persons
                                                                                          && x.Act.commissioningDate >= dtpFirst.SelectedDate
                                                                                          && x.Act.commissioningDate <= dtpSecond.SelectedDate).ToList();
                            break;
                        case "Предприятие":
                            int abv = Convert.ToInt32(cb_item.SelectedValue);
                            var testobj1 = OdbConnectHelper.entObj.Company.FirstOrDefault(x => x.ID_company == abv);
                            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.Responsible_persons.ID_company == testobj1.ID_company
                                                                                          && x.Act.commissioningDate >= dtpFirst.SelectedDate
                                                                                          && x.Act.commissioningDate <= dtpSecond.SelectedDate).ToList();
                            break;
                        case "Статус":
                            int abv1 = Convert.ToInt32(cb_item.SelectedValue);
                            var testobj2 = OdbConnectHelper.entObj.Status.FirstOrDefault(x => x.ID_status == abv1);
                            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.ID_status == testobj2.ID_status
                                                                                          && x.Act.commissioningDate >= dtpFirst.SelectedDate
                                                                                          && x.Act.commissioningDate <= dtpSecond.SelectedDate).ToList();
                            break;
                        default:
                            break;
                    }
                }
                else
                {
                    GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.Act.commissioningDate >= dtpFirst.SelectedDate && x.Act.commissioningDate <= dtpSecond.SelectedDate).ToList();
                }
            }

        }
        
        private void btnDecommission_click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (GridList.SelectedItems.Count > 0)
                {
                    MessageBoxResult result = MessageBox.Show($"Вы действительно хотите списать {GridList.SelectedItems.Count} запись(-и)?",
                                                          "Предупреждение",
                                                          MessageBoxButton.YesNo,
                                                          MessageBoxImage.Warning);
                    if (result == MessageBoxResult.Yes)
                    {
                        for (int i = 0; i < GridList.SelectedItems.Count;)
                        {
                            Product_map ProductMap = GridList.SelectedItems[i] as Product_map;
                            if (ProductMap != null)
                            {
                                Archiev archObj = new Archiev()
                                {
                                    number_act = ProductMap.number_act,
                                    ArchivationDate = System.DateTime.Now
                                };
                                OdbConnectHelper.entObj.Archiev.Add(archObj);
                                OdbConnectHelper.entObj.Product_map.Remove(ProductMap);
                                OdbConnectHelper.entObj.SaveChanges();
                                GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.ToList();
                            }
                            else
                            {
                                return;
                            }
                        }
                        GridList.SelectedIndex = 0;
                        MessageBox.Show($"Продукт успешно списан",
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);;
                    }
                    if (result == MessageBoxResult.No)
                        return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(),
                                "Ошибка: Не выбрано поле",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);
            }
        }

        private void tbsearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            GridList.ItemsSource = OdbConnectHelper.entObj.Product_map.Where(x => x.inventory_number.ToString().StartsWith(tbsearch.Text)).ToList();
        }

        private void LimitText_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0)) { e.Handled = true; }
        }
    }
}
