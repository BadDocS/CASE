﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TMC_case_team4.Data;
using TMC_case_team4.Pages.PageAddFunction;

namespace TMC_case_team4.Pages.MainPages
{
    /// <summary>
    /// Логика взаимодействия для PageNaznachenie.xaml
    /// </summary>
    
    public partial class PageNaznachenie : Page
    {
        public static int idAct;
        public PageNaznachenie()
        {
            InitializeComponent();

            GridList.ItemsSource = OdbConnectHelper.entObj.Act.ToList();
            List<string> list = new List<string> { "Номер акта", "Название продукта"};
            cb_sort.ItemsSource = list;
           
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageAddNaznachenie());
        }


        private void btn_edit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OdbConnectHelper.entObj.SaveChanges();
                MessageBox.Show("Изменения применены",
                                "Уведомление",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(),
                                "Ошибка",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);
            }
        }
                     
        private void btn_reset_Click(object sender, RoutedEventArgs e)
        {
            cb_sort.Text = "";
            tb_item.Visibility = Visibility.Hidden;
            GridList.ItemsSource = OdbConnectHelper.entObj.Act.ToList();
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            //GridList.ItemsSource = OdbConnectHelper.entObj.Company_and_division.ToList();
        }
        //GridList.ItemsSource = OdbConnectHelper.entObj.Product.Where(x => x.title.StartsWith(tb_search.Text)).ToList();
        private void tb_item_TextChanged(object sender, TextChangedEventArgs e)
        {
            tb_item.IsEnabled = true;
            switch (cb_sort.SelectedItem.ToString())
            {
                case "Номер акта":
                    var numActObj = OdbConnectHelper.entObj.Act.Where(x => x.number_act.ToString().StartsWith(tb_item.Text)).ToList();
                    GridList.ItemsSource = numActObj;
                    break;
                case "Название продукта":
                    var nameProdObj = OdbConnectHelper.entObj.Act.Where(x => x.Product.title.StartsWith(tb_item.Text)).ToList();
                    GridList.ItemsSource = nameProdObj;
                    break;
                case "":
                    break;
                default:
                    break;
            }
        }

        private void btnInfo_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageInfoStatus((sender as Button).DataContext as Act));
        }

        private void cb_sort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            tb_item.Visibility = Visibility.Visible;
        }
    }
}
