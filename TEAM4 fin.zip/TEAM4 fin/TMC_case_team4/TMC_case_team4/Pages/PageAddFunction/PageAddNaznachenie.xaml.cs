﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TMC_case_team4.Data;

namespace TMC_case_team4.Pages.PageAddFunction
{
    /// <summary>
    /// Логика взаимодействия для PageAddNaznachenie.xaml
    /// </summary>
    public partial class PageAddNaznachenie : Page
    {
        public PageAddNaznachenie()
        {
            InitializeComponent();

            cbProd.SelectedValuePath = "ID_product";
            cbProd.DisplayMemberPath = "title";
            cbProd.ItemsSource = OdbConnectHelper.entObj.Product.ToList();
        }

        private void btnAddCardProd_Click(object sender, RoutedEventArgs e)
        {
            if (tbCount.Text.Length != 0)
            {
                Act actAddObj = new Act()
                {
                    number_act = OdbConnectHelper.entObj.Act.Max(x => x.number_act) + 1,
                    count = int.Parse(tbCount.Text),
                    commissioningDate = DateTime.Now,
                    ID_product = (int)cbProd.SelectedValue
                };

                OdbConnectHelper.entObj.Act.Add(actAddObj);
                OdbConnectHelper.entObj.SaveChanges();
                MessageBox.Show("Акт Добавлен, не забудте обновить таблицу");
                FrameApp.frmObj.GoBack();
            }
            else
            {
                MessageBox.Show("Укажите количество!");
            }
        }

        private void LimitText_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (!Char.IsDigit(e.Text, 0)) { e.Handled = true; }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.GoBack();
        }
    }
}
